pip install moviepy imageio[ffmpeg]


sudo nano /etc/ImageMagick-6/policy.xml
<policy domain="path" rights="read | write" pattern="@*"/>